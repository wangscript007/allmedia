#include "oss_config.h"

const char OSS_ENDPOINT[] = "<your endpoint>";
const char ACCESS_KEY_ID[] = "<your access key id>";
const char ACCESS_KEY_SECRET[] = "<your access key secret>";
const char BUCKET_NAME[] = "<your bucket name>";
const char OBJECT_NAME[] = "<your object key>";
const char MULTIPART_UPLOAD_FILE_PATH[] = "<your local file>";

//surfix must be '/', only used for dir relative sample
const char DIR_NAME[] = "dir/"; 
