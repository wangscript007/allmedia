#include "oss_config.h"

char* TEST_OSS_ENDPOINT = NULL;
char* TEST_ACCESS_KEY_ID = NULL;
char* TEST_ACCESS_KEY_SECRET = NULL;
char* TEST_BUCKET_NAME = NULL;
